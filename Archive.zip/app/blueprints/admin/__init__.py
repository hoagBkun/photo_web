from .routes import admin_bp

__all__ = ['admin']